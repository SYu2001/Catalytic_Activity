rm EneVskpoints-unitcell.dat
for ((i=3;i<=15;i++))
 do ene=`grep "ENERGY| Total FORCE_EVAL ( QS ) energy (a.u.): " kpoints_$i/log.out | tail -1 | awk '{print $9}'` ; 
echo $i $ene
echo $i $ene >> EneVskpoints-unitcell.dat
done 
